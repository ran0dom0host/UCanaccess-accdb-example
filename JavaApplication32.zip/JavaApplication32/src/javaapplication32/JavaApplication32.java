package javaapplication32;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author m8613
 */
public class JavaApplication32 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
              Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");//Loading Driver

              Connection connection2= DriverManager.getConnection("jdbc:ucanaccess://D:\\NB-DevDir\\JavaApplication32\\northwind.accdb;jackcessOpener=javaapplication32.CryptCodecOpener", "user", "12345678");//Establishing Connection
              System.out.println("Connected Successfully");


              PreparedStatement preparedStatemen2=connection2.prepareStatement("SELECT TOP 20 Products.[Product Name], [Order Details].* FROM Products INNER JOIN [Order Details] ON Products.ID = [Order Details].[Product ID]");

              ResultSet resultSet2=preparedStatemen2.executeQuery();

                
            if (!resultSet2.next()) {
                     System.out.println("conn2 null");
                  } else {
                       System.out.println("conn2 not null");
                   while(resultSet2.next()){
                   String OID=resultSet2.getString("Order ID");
                   String Pname=resultSet2.getString("Product Name");
                   String Uprice=resultSet2.getString("Unit Price");
                   //Printing Results
                   System.out.println(OID + " "+ Pname+" Price"+ Uprice);
              }
                  }

              //resultSet.next();
               

          }catch(Exception e){
              //System.out.println("Error in connection");
              e.printStackTrace();
 
          }
        
    }
    
}